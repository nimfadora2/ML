theta=[1;1]
Xt=[ones(m, 1) X];
Xt*theta
