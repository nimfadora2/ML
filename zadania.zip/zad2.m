close all;
clear all;

dzien=10;
rok=1995;
rand('state',dzien*rok);
randn('state',dzien*rok);

%zbi�r ucz�cy
x = [ones(200,1) rand(200,30)*2-1 ];
wp = [1 rand(1,10)*0.5+0.5, rand(1,10)*0.3, zeros(1,10)]'; 
y = (wp'*x' + randn(1,200)*0.1)';

%zbi�r testowy
xt = [ones(200,1) rand(200,30)*2-1];
yt = (wp'*xt' + randn(1,200)*0.1)';

[~,~,~,inmodel]=stepwisefit(x(:,2:end),y);
x3=x(:,[true inmodel]); %usuni�cie nieistotnych atrybut�w

% numery istotnych atrybutow 1 2 3 4 5 6 7 8 9 10 12 13 14 15 17 18 19 20

% Aproksymowane wartosci funkcji
w3 = (x3'*x3)^(-1)*x3'*y;
y3=(w3'*x3')';

% Blad aproksymacji zbioru uczacego
E3 = sum((y3-y).^2);

% Blad aproksymacji zbioru testowego
x3t = xt(:,[true inmodel]);
y3t = (w3'*x3t')';
E3t = sum((y3t-yt).^2);

% regresja grzbietowa
lambda=0:1000;
w4=ridge(y,x(:,2:end),lambda,0);

figure
plot(lambda,w4);
title('Wagi w zaleznosci od \lambda')

  for i=1:length(lambda)
            y4(:,i)=(w4(:,i)'*x')';
            E4(i)=sum((y-y4(:,i)).^2);
  end
  
figure
plot(lambda,E4)
title('E4')

  for i=1:length(lambda)
            yt4(:,i)=(w4(:,i)'*xt')';
            Et4(i)=sum((yt-yt4(:,i)).^2);
  end

figure
plot(lambda,Et4)
title('Et4')

% Regresja LASSO

lambda=0:0.001:1;
[w5, FitInfo] = lasso(x(:,2:end),y,'Lambda',lambda); 
w5_0=FitInfo.Intercept;

figure
plot(lambda,w5)
hold on
plot(lambda,w5_0)


for i=1:length(lambda)
    y5(:,i)=([w5_0(i); w5(:,i)]'*x')';
    E5(i)=sum((y-y5(:,i)).^2);
end

figure
plot(lambda,E5)

for i=1:length(lambda)
    yt5(:,i)=([w5_0(i); w5(:,i)]'*xt')';
    Et5(i)=sum((yt-yt5(:,i)).^2);
end

figure
plot(lambda,Et5)
